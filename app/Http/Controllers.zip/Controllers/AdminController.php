<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use DB;
use Auth;
use Redirect;
use App\Company;
use App\Comment;
use Carbon\Carbon;
use Session;

class AdminController extends Controller
{

    public function showStatics()
    {
        $fetch = DB::table('reports')->get();
        
        $post = DB::table('reports')->get('*')->toArray();
        foreach($post as $row)
        {
            $data[] = array
            (
                'label'=>$row->cilient_name,
                'y'=>$row->total_payment

            );
        }
        return view("chart3", ["data" => $data], compact("fetch"));
    }
    
    public function all_users()
    {
        $user=User::all();
        return view("admin.all-users",compact("user"));
    }

    public function admin_profile()
    {

        $user = Auth::user()->email;
        $user_check = User::where('email',$user)->get();
        return view("admin.profile",compact("user_check"));
    }

    public function all_company_details()
    {
        $allcompany = DB::table('companies')
                ->Join('users','users.id','companies.user_id')->orderBy('uuid','asc')->skip(5)->paginate(5);
                //dd("$allcompany");
                $totalcompany = Company::all()->count();
                
                $showcomment = DB::table('users')
                ->Join('comments','comments.user_id','users.id')->
               get();
        //dd("$showcomment");
               
               return view("admin.all-company",compact("allcompany","totalcompany","showcomment"));
                
    }

    public function admin_update_company(Request $request, $uuid)
    {
        //$check = Company::findOrFail($gst_no);
        $company = Company::where('uuid',$uuid)->first();
        //return $company;
        return view("admin.admin-edit-company",compact("company")); 
    }

    public function admin_updateCompany(Request $request, $gst_no)
    {
        Company::where('gst_no',$gst_no)->update([
        //$company = Company::find($id);
        'data_source'=>$request->input('data_source'),
        'company_name'=>$request->input('company_name'),
        'address'=>$request->input('address'),
        'gst_no'=>$request->input('gst_no'),
        'website_url'=>$request->input('website_url'),
        'established_year'=>$request->input('established_year'),
        
       
        'designation'=>$request->input('designation'),
        'email'=>$request->input('email'),
        'mobile_no'=>$request->input('mobile_no'),
        ]);
         return Redirect::back()->with('success', 'Company Information Update Successfully');

         
    }

    public function admin_dlt_company($uuid)
    {
      $company=Company::findOrFail($uuid);
      $company->delete();
      return Redirect::back()->with('success', 'Company Information Delete Successfully');
    }

     public function shift_data()
    {
        $users=User::get();
        
        foreach($users as $key => $value)
        {
            Company::create
            ([
                'data_sources'=>$value->name,
                'user_id'=>$value->id,

            ]);
            return 'Shift Data';
        }
        
    }
    public function shift_data2(Request $request)
    {
         
        $check = Company::where('uuid',$request->select)->first();
                //return $check;
         $shift = Company::all();
         //$request->session()->put('name', $request->input('select'));
        
         return view("admin.transfer-data",compact("shift","check"))->with('name',$request->session()->get('name'));
      
    }

    public function shift_transfer_data(Request $request)
    {   
        
        
        $company2 = Company::where('user_id',$request->category)->first();
        $name=$company2->emp_name;
        //return $name;
        //$company = Company::where('uuid',$request->select)->first();
        
        //dd("$company");
        $id=$request->select;
        //return $id;
        Company::where('uuid', $id)
       ->update([
           'user_id' => $request->category,
           'emp_name'=> $name,
        ]);
        /*$company= Company::where('uuid',$id)->first();
        $company->user_id=$request->category;
        $company->emp_name=$name;
        $company->save();*/
        //dd("$company");
        return redirect('/admin/all_company_details')->with('success','Leads Transfer To Another Employee Successfully');
      //return $request->category;
      //$user = Company::where('user_id', $select_id);*/

    }

    public function search_admin_company(Request $request)
    {
      $search = $request->search_company;
      $searchCom= Company::where('mobile_no',$search)->get();
      
      return view("admin.partisearch",compact("searchCom"));
    }

    public function search_company()
    {
        return view("admin.search-company");
    }

    public function admin_all_info($uuid)
    {
         $showcomment = DB::table('companies')->where('uuid',$uuid)->get();
         return view("admin.admin-all-info",compact("showcomment"));
    }

    public function today_company()
    {
        $data = Company::whereDate('created_at',  Carbon::today()->toDateString())->paginate(10);
        $Company = Company::whereDate('created_at',  Carbon::today()->toDateString())->count();
        return view("admin.today-company",compact("data","Company"));
    }

    public function my_company()
    {
        $emp = User::all();
        return view("admin.my-emp-name",compact("emp"));
    }

    public function emp_single_com(Request $request, $id)
    {
       $Com = Company::where("user_id",$id)->first();
       $sinCom = $Com->emp_name;
       
       $check = $Com->user_id;
        Session::put('name',$check);
        $data = session::get('name');
        //return $data;
      
      $no = DB::table('companies')->where('status',"Not Open")->where('user_id',"$id")->count();
        //return $data; 
        $cb = DB::table('companies')->where('status',"Call Back")->where('user_id',"$id")->count();
        $td = DB::table('companies')->where('status',"Tele DMU")->where('user_id',"$id")->count();
        $pg = DB::table('companies')->where('status',"PG")->where('user_id',"$id")->count();
        $sv = DB::table('companies')->where('status',"Services")->where('user_id',"$id")->count();
        $ni = DB::table('companies')->where('status',"NI")->where('user_id',"$id")->count();
        $con = DB::table('companies')->where('status',"Converted")->where('user_id',"$id")->count();

        $wr = DB::table('companies')->where('status',"Wrong No")->where('user_id',"$id")->count();
        $nt = DB::table('companies')->where('status',"Non Target")->where('user_id',"$id")->count();
        $ccl = DB::table('companies')->where('status',"Company Closed")->where('user_id',"$id")->count();
        $total = DB::table('companies')->where('user_id',"$id")->count('status');
        
      return view("admin.status.sing-emp-status",compact("no","cb","td","pg","sv","ni","con","wr",
            "nt","ccl","total","sinCom"));
      
    }
    
    
     public function not_open(Request $request)
     {
        $not_open = "Not Open";
        $user = session::get('name');
        $data = Company::where('status',$not_open)->where('user_id',$user)->paginate(6);
        return view("admin.status.status",compact("data"));
        
    }

     public function dmu()
     {
        $user = session::get('name');
        $dm = "DMU";
        $data = Company::where('status',$dm)->where('user_id',"$user")->paginate(6);
        return view("admin.status.dmu",compact("data"));
     }

     public function call_back()
     {
        $user = session::get('name');
        $cb = "Call Back";
        $data = Company::where('status',$cb)->where('user_id',"$user")->paginate(6);
        return view("admin.status.status",compact("data"));
     }

     public function tele_dmu()
     {
        $user = session::get('name');
        $td = "Tele Dmu";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("admin.status.status",compact("data"));
     }

      public function pg()
     {
        $user = session::get('name');
        $td = "PG";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("admin.status.status",compact("data"));
     }
      public function sv()
     {
        $user = session::get('name');
        $td = "Services";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("admin.status.status",compact("data"));
     }
      public function ni()
     {
        $user = session::get('name');
        $td = "NI";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("admin.status.status",compact("data"));
     }
      public function con()
     {
        $user = session::get('name');
        $td = "Converted";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("admin.status.status",compact("data"));
    }

    public function ccl()
     {
        $user = session::get('name');
        $td = "Company Closed";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("admin.status.status",compact("data"));
    }

    public function nt()
     {
        $user = session::get('name');
        $td = "Non Target";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("admin.status.status",compact("data"));
    }

    public function wr()
     {
        $user = session::get('name');
        $td = "Wrong No";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("admin.status.status",compact("data"));
    }

    
    public function admin_refill($uuid)
     {
        $refill = Company::where('uuid',$uuid)->first();
        // return $refill;
        return view("admin.admn-refill",compact("refill"));
     }

     public function admin_refill_data(Request $request, $uuid)
     {
        Company::where('uuid',$uuid)->update([

            'com_reg_date'=>$request->input('com_reg_date'),
            'reg_by'=>$request->input('reg_by'),
            'company_name'=>$request->input('company_name'),
            'brand_name'=>$request->input('brand_name'),
            'established_year'=>$request->input('established_year'),
            'category'=>$request->input('category'),
            'sale'=>$request->input('sale'),
            'buy'=>$request->input('buy'),
            'cus_name'=>$request->input('cus_name'),
            'designation'=>$request->input('designation'),
            'mobile_no'=>$request->input('mobile_no'),
            'whats_no'=>$request->input('whats_no'),
            'alternate_no'=>$request->input('alternate_no'),
            'email'=>$request->input('email'),
            'address'=>$request->input('address'),

            'buy_sell'=>$request->input('buy_sell'),
            'major_product'=>$request->input('major_product'),
            'min_to_max'=>$request->input('min_to_max'),
            'req_frequ'=>$request->input('req_frequ'),
            'quality_size_speci'=>$request->input('quality_size_speci'),
            'purpose_of_req'=>$request->input('purpose_of_req'),
            'packaging_size'=>$request->input('packaging_size'),
            'delivery_place'=>$request->input('delivery_place'),
            'tar_of_busi_area'=>$request->input('tar_of_busi_area'),

            'paymentterm'=>$request->input('paymentterm'),
            'req_urgen'=>$request->input('req_urgen'),
            'website_url'=>$request->input('website_link'),
            'other_investment'=>$request->input('other_investment'),
            'response'=>$request->input('response'),
            'gst_no'=>$request->input('gst_no'),
            'pan_no'=>$request->input('pan_no'),
            'tan_no'=>$request->input('tan_no'),
            'cin_no'=>$request->input('cin_no'),
            'bank_name'=>$request->input('bank_name'),
            'account_type'=>$request->input('account_type'),

            'adhar_no'=>$request->input('adhar_no'),
            'fssai'=>$request->input('fssai'),
            'lab_testing_report'=>$request->input('lab_testing_report'),
            'export_licence'=>$request->input('export_licence'),
            'data_source'=>$request->input('data_source'),
            'remark'=>$request->input('remark'),
            'conversation_details'=>$request->input('conversation_details'),
            'online_demo'=>$request->input('online_demo'),
            'executive_feedback'=>$request->input('executive_feedback'),
            'brand_name'=>$request->input('propsal_name'),
            'product_img'=>$request->input('product_img'),
            'fp_user_id'=>$request->input('fp_user_id'),

            'fp_psw'=>$request->input('fp_psw'),
            'bwt_catalog_link'=>$request->input('bwt_catalog_link'),
            'whats_up'=>$request->input('whats_up'),
            'executive_name'=>$request->input('executive_name'),
            'tl_manager_name'=>$request->input('tl_manager_name'),
          ]);
        return Redirect::back()->with('success', 'Company Register Data Update Successfully');
     }
      
      public function admin_comment($uuid)
      {
        $checkComment = Company::where('uuid',$uuid)->first();
        
        return view("admin.status/update-com-status",compact("checkComment"));
      }
      
      
}
