<?php

namespace App\Http\Controllers;
use Auth;
use App\User;
use App\Comment;
use App\Company;
use Redirect;
use DB;
use Validator;
use Carbon\Carbon;

use Illuminate\Http\Request;

class VendorController extends Controller
{
    public function company()
    {
        $data['countries'] = User::get(["name", "id"]);
        return view("vendor.company", $data);
    }
    public function add_company()
    {
        $data= Validator::make($request->all(),[
        "name"=>"required",
        "email"=>"required",
        "mobile"=>"required",
        "qualification"=>"required",
        
        ],
        [
          "mobile.required"=>"Please Enter Your Valid Mobile No.",
        ])->validate();
        
         $details = [

        'title' => $request->email,
        'body' =>  $request->password
         ];

        $emails = [$request->input('email')];
        \Mail::to($emails)->send(new \App\Mail\MyTestMail($details));

       
       $emp_id = Helper::IDGenerator(new User, 'emp_id', 5, 'BWT');

       $user = new User;
       $user->emp_id = $emp_id;
       $user->name = $request->input('name');
       $user->email = $request->input('email');
       $user->mobile = $request->input('mobile');
       $user->qualification = $request->input('qualification');
       $user->password = Hash::make($request->input('password'));
       $user->save();
       return Redirect::back()->with('success', 'User Register Successfully');
    }

    public function sfa()
    {
        return view("vendor.sfa");
    }

     public function search_company()
    {
        
        return view("vendor.search_company");
    }

    public function profile()
    {

        $user = Auth::user()->email;
        $user_check = User::where('email',$user)->get();
        return view("vendor.profile",compact("user_check"));
    }

    public function add_company_data(Request $request)
    {
        $data= Validator::make($request->all(),[
        
        
        "mobile_no"=>"required|unique:companies",
        
        
        ],
        [
          
          "mobile_no.unique"=>"This Company Already Register!",
        ])->validate();
        
        $company_data = new Company;
        $company_data->user_id=Auth::user()->id;
        $company_data->emp_name=Auth::user()->name;

        $company_data->com_reg_date=$request->com_reg_date;
        $company_data->reg_by=$request->reg_by;
        $company_data->brand_name=$request->brand_name;
        $company_data->category=$request->category;
        $company_data->firm_type=$request->firm_type;
        $company_data->sale=$request->sale;

        $company_data->buy=$request->buy;
        $company_data->cus_name=$request->cus_name;
        $company_data->alternate_no=$request->alternate_no;
        $company_data->whats_no=$request->whats_no;

        $company_data->company_name=$request->company_name;
        $company_data->address=$request->address;

        $company_data->gst_no=$request->gst_no;
        $company_data->website_url=$request->website_link;
        $company_data->established_year=$request->established_year;
        $company_data->designation=$request->designation;
        $company_data->email=$request->email;
        $company_data->mobile_no=$request->mobile_no;

        $company_data->buy_sell=$request->buy_sell;
        $company_data->major_product=$request->major_product;
        $company_data->min_to_max=$request->min_to_max;
        $company_data->req_frequ=$request->req_frequ;

        $company_data->quality_size_speci=$request->quality_size_speci;
        $company_data->purpose_of_req=$request->purpose_of_req;
        $company_data->packaging_size=$request->packaging_size;
        $company_data->delivery_place=$request->delivery_place;

        $company_data->tar_of_busi_area=$request->tar_of_busi_area;
        $company_data->paymentterm=$request->paymentterm;
        $company_data->req_urgen=$request->req_urgen;
        $company_data->other_investment=$request->other_investment;

        $company_data->response=$request->response;
        $company_data->pan_no=$request->pan_no;
        $company_data->tan_no=$request->tan_no;
        $company_data->cin_no=$request->cin_no;

        $company_data->bank_name=$request->bank_name;
        $company_data->account_type=$request->account_type;
        $company_data->adhar_no=$request->adhar_no;
        $company_data->fssai=$request->fssai;

        $company_data->lab_testing_report=$request->lab_testing_report;
        $company_data->export_licence=$request->export_licence;
        $company_data->data_source=$request->data_source;
        $company_data->status=$request->status;

        $company_data->conversation_details=$request->conversation_details;
        $company_data->online_demo=$request->online_demo;
        $company_data->executive_feedback=$request->executive_feedback;
        $company_data->propsal_name=$request->propsal_name;

        $company_data->product_img=$request->product_img;
        $company_data->fp_user_id=$request->fp_user_id;
        $company_data->fp_psw=$request->fp_psw;
        $company_data->bwt_catalog_link=$request->bwt_catalog_link;
        $company_data->whats_up=$request->whats_up;
        $company_data->executive_name=$request->executive_name;
        
        $company_data->tl_manager_name=$request->tl_manager_name;

        $company_data->user_fp_link=$request->user_fp_link;
        $company_data->visitors_coun=$request->visitors_coun;
        $company_data->inquery_send=$request->inquery_send;
        $company_data->verify_buy_lead=$request->verify_buy_lead;
        $company_data->ratiing=$request->ratiing;
        $company_data->convert_rs=$request->convert_rs;
        $company_data->save();
        return Redirect::back()->with('success', 'New Company Created Successfully');
    }
    
    public function my_data()
    {
        $foreign=Auth::user()->id;
        $allcompany = Company::where('user_id',$foreign)->get();
        $totalcompany = Company::where('user_id',$foreign)->count();

        

        return view("vendor.all-company",compact("allcompany","totalcompany"));
    }

    public function update_company(Request $request, $uuid)
    {
       
        $company = Company::where('uuid',$uuid)->first();
        
        return view("vendor.edit-company",compact("company")); 
    }

    public function updateCompany(Request $request, $uuid)
    {
        Company::where('uuid',$uuid)->update([
        'data_source'=>$request->input('data_source'),
        'company_name'=>$request->input('company_name'),
        'address'=>$request->input('address'),
        'gst_no'=>$request->input('gst_no'),
        'website_url'=>$request->input('website_url'),
        'established_year'=>$request->input('established_year'),
        
        'cus_name'=>$request->input('cus_name'),
        'designation'=>$request->input('designation'),
        'email'=>$request->input('email'),
        'mobile_no'=>$request->input('mobile_no'),
        ]);
        return Redirect::back()->with('success', 'Company Information Update Successfully');
    }

    public function dlt_company($uuid)
    {
      $company=Company::findOrFail($uuid);
      $company->delete();
      return Redirect::back()->with('success', 'Company Information Delete Successfully');
    }

    public function shift_data($id)
    {
        $users=User::get();
        
        foreach($users as $key => $value)
        {
            Company::create
            ([
                'data_sources'=>$value->name,
                'user_id'=>$value->id,

            ]);
            return 'Shift Data';
        }
        
    }

    public function comment($uuid)
    {
        $checkComment = Company::where('uuid',$uuid)->first();
        //return $checkComment;
        //$oldcom = Company::where('uuid',$uuid)->first();
        return view("vendor.add-comment",compact("checkComment"));

        /*$2checkComment = Comment::where('company_id',$uuid)->first();
        if($checkComment)
        {
        $oldcom = Comment::where('company_id',$uuid)->first();
        $comment = Company::where('uuid',$uuid)->first();
        return view("vendor.add-comment",compact("comment","oldcom"));
        }
        else
        {
            $checkComment = Comment::where('company_id',$uuid)->first();
            $objComment = new Comment;
            
            $comment = Company::where('uuid',$uuid)->first();
            $objComment->company_id=$comment->uuid;
            $objComment->user_id=$comment->user_id;
            $objComment->comp_name=$comment->company_name;
            $objComment->emp_name=$comment->emp_name;
            $objComment->save();
            return Redirect::back()->with('success', 'User Added Successfully');
        }*/
      
       
    }

    
    public function add_comment(Request $request,$uuid)
    {   
        $old = $request->oldcomment;
        $new = $request->comment;
       
        $combine=array($old,$new);
        $latestcomment=implode("/:",$combine);

        Company::where('uuid',$uuid)->update([
        
        'comment'=>$latestcomment,
        'status'=>$request->input('status'),
        'next_call_timing'=>$request->input('next_followup'),
        
        ]);
        return Redirect::back()->with('success', 'Your Client Feedback Send Successfully');
    }
    
    public function all_info(Request $request,$uuid)//for fetch single company full data
    {
        $allcompany = DB::table('companies')->where('uuid',$uuid)->get();
        
        //$var = $allcompany->user_id;
        //$empid = User::where('id',$var)->get();
        //$empidfetch = $empid->emp_id;
        //return $empidfetch;
         //return $empid;

        //return $user;
        /*$allcompany = DB::table('companies')
                ->Join('comments','comments.company_id','companies.uuid')->
                where('companies.uuid',$uuid)->
                get();*/

        return view("vendor.all-info",compact("allcompany"));
        
    }


    public function search_vendor_company(Request $request)
    {
        //return $request->search_company;
        $data= Validator::make($request->all(),[
        "search_company"=>"required",
        
        ],
        [
          "search_company.numeric"=>"Please Enter Only Profile Id & Mobile No.",
        ])->validate();
       
       $check = Company::where('uuid',$request->search_company)->orwhere('mobile_no',$request->search_company)->orwhere('company_name',$request->search_company)->first();
       //return $check;

       if($check)
      {
        //dd("yes");
        $search = $request->search_company;
        $searchCom= Company::where('uuid',$search)->orwhere('mobile_no',$search)->orwhere('company_name',$request->search_company)->get();
        //dd("$searchCom");
        // for display only comment from comment field

        $fetchmobile= Company::where('uuid',$search)->orwhere('mobile_no',$search)->orwhere('company_name',$request->search_company)->first();
        $no=$fetchmobile->uuid;
        $comment = Comment::where('company_id',$no)->get();
        //return $comment;
        return view("vendor.includesearch",compact("searchCom","comment"));
       }
      else
      {
        /*return redirect()->route('Vendor_details.index')->with('jsAlert', 'updated succesfully');*/
        //dd("no");
         return Redirect::back()->with('alert_msg', 'Data Not Match');
        dd("No");
      }
    }

    public function showsearch3()
    {
        if($request->ajax())
        {
            return view("vendor.livesearch",compact("searchCom"));
        }
    }
     
     // function for filter data date vise
     public function filter_data(Request $request)
     {
         $user = Auth::user()->id;
         $todayCompany = Company::whereDate('next_call_timing','=',Carbon::today()->toDateString())->where('user_id',"$user")->get();
         
         $due = Company::whereDate('next_call_timing','<', Carbon::today()->toDateString())->where('user_id',"$user")->count();
         //return $due;
        
         $no = Company::where('status',"Not Open")->where('user_id',"$user")->count();
        //return $data; 
        $cb = Company::where('status',"Call Back")->where('user_id',"$user")->count();
        $td = Company::where('status',"Tele DMU")->where('user_id',"$user")->count();
        $pg = Company::where('status',"PG")->where('user_id',"$user")->count();
        $sv = Company::where('status',"Services")->where('user_id',"$user")->count();
        $ni = Company::where('status',"NI")->where('user_id',"$user")->count();
        $con = Company::where('status',"Converted")->where('user_id',"$user")->count();

        $wr = Company::where('status',"Wrong No")->where('user_id',"$user")->count();
        $nt = Company::where('status',"Non Target")->where('user_id',"$user")->count();
        $ccl = Company::where('status',"Company Closed")->where('user_id',"$user")->count();

        $total = Company::where('user_id',"$user")->count('status');
        //return $total;
           
        return view("vendor.filter-data",compact("no","cb","td","pg","sv","ni","con","wr",
            "nt","ccl","total","todayCompany","due"));
     }

     public function filter_data_result(Request $request)
     {
        $user = Auth::user()->id;
        $sdate = $request->input("sdate");
        $edate = $request->input("edate");
        $status = $request->input("status");

        $query = DB::table('companies')->select()
        ->where('created_at','>=',$sdate)
        ->where('created_at','<=',$edate)
        ->where('status',$status)
        ->where('user_id',"$user")
        ->get();
        
        $totalcompany = DB::table('companies')->select()
        ->where('created_at','>=',$sdate)
        ->where('created_at','<=',$edate)
        ->where('status',$status)
        ->where('user_id',"$user")
        ->count();
        return view("vendor.filter-data-result",compact("query","totalcompany"));
     }


     public function not_open(Request $request)
     {
        if($not_open = "Not Open")
        {
            $user = Auth::user()->id;
            $data = Company::where('status',$not_open)->where('user_id',"$user")->paginate(6);
            return view("vendor.status.status",compact("data"));
        }
    }

     public function dmu()
     {
        $user = Auth::user()->id;
        $dm = "DMU";
        $data = Company::where('status',$dm)->where('user_id',"$user")->paginate(6);
        return view("vendor.status.status",compact("data"));
     }

     public function call_back()
     {
        $user = Auth::user()->id;
        $cb = "Call Back";
        $data = Company::where('status',$cb)->where('user_id',"$user")->paginate(6);
        return view("vendor.status.status",compact("data"));
     }

     public function tele_dmu()
     {
        $user = Auth::user()->id;
        $td = "Tele Dmu";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("vendor.status.status",compact("data"));
     }

      public function pg()
     {
        $user = Auth::user()->id;
        $td = "PG";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("vendor.status.status",compact("data"));
     }
      public function sv()
     {
        $user = Auth::user()->id;
        $td = "Services";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("vendor.status.status",compact("data"));
     }
      public function ni()
     {
        $user = Auth::user()->id;
        $td = "NI";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("vendor.status.status",compact("data"));
     }
      public function con()
     {
        $user = Auth::user()->id;
        $td = "Converted";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("vendor.status.status",compact("data"));
    }

    public function ccl()
     {
        $user = Auth::user()->id;
        $td = "Company Closed";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("vendor.status.status",compact("data"));
    }

    public function nt()
     {
        $user = Auth::user()->id;
        $td = "Non Target";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("vendor.status.status",compact("data"));
    }

    public function wr()
     {
        $user = Auth::user()->id;
        $td = "Wrong No";
        $data = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("vendor.status.status",compact("data"));
    }
    
     public function due()
     {
        $user = Auth::user()->id;
        $data = Company::whereDate('next_call_timing','<',Carbon::today()->toDateTimeString())->where('user_id',"$user")->paginate(6);
        
        //$fdata = Company::where('status',$td)->where('user_id',"$user")->paginate(6);
        return view("vendor.status.status",compact("data"));
    }

    public function vendor_shift_leads(Request $request)
    {
         $check = Company::where('uuid',$request->select)->first();
                //return $check;
         $shift = Company::all();
         //$request->session()->put('name', $request->input('select'));
        
         return view("vendor.transfer-vendor-leads",compact("shift","check"));
      
    }

    public function vendor_leads_change(Request $request)
    {   
        
        
        $company2 = Company::where('user_id',$request->category)->first();
        //return $company2;
        $name=$company2->emp_name;
        $id=$request->select;

        Company::where('uuid', $id)
       ->update([
           'user_id' => $request->category,
           'emp_name'=> $name,

        ]);
       
        return Redirect::back()->with('success', 'Company Information Update Successfully');
     }

     public function refill($uuid)
     {
        $refill = DB::table('companies')->where('uuid',$uuid)->first();
       // return $refill;
        return view("vendor.refill",compact("refill"));
     }

     public function refill_data(Request $request, $uuid)
     {
         //return $request->input();
        Company::where('uuid',$uuid)->update([

            'com_reg_date'=>$request->input('com_reg_date'),
            'reg_by'=>$request->input('reg_by'),
            'company_name'=>$request->input('company_name'),
            'brand_name'=>$request->input('brand_name'),
            'established_year'=>$request->input('established_year'),
            'category'=>$request->input('category'),
            'sale'=>$request->input('sale'),
            'buy'=>$request->input('buy'),
            'cus_name'=>$request->input('cus_name'),
            'designation'=>$request->input('designation'),
            'mobile_no'=>$request->input('mobile_no'),
            'whats_no'=>$request->input('whats_no'),
            'alternate_no'=>$request->input('alternate_no'),
            'email'=>$request->input('email'),
            'address'=>$request->input('address'),

            'buy_sell'=>$request->input('buy_sell'),
            'major_product'=>$request->input('major_product'),
            'min_to_max'=>$request->input('min_to_max'),
            'req_frequ'=>$request->input('req_frequ'),
            'quality_size_speci'=>$request->input('quality_size_speci'),
            'purpose_of_req'=>$request->input('purpose_of_req'),
            'packaging_size'=>$request->input('packaging_size'),
            'delivery_place'=>$request->input('delivery_place'),
            'tar_of_busi_area'=>$request->input('tar_of_busi_area'),

            'paymentterm'=>$request->input('paymentterm'),
            'req_urgen'=>$request->input('req_urgen'),
            'website_url'=>$request->input('website_link'),
            'other_investment'=>$request->input('other_investment'),
            'response'=>$request->input('response'),
            'gst_no'=>$request->input('gst_no'),
            'pan_no'=>$request->input('pan_no'),
            'tan_no'=>$request->input('tan_no'),
            'cin_no'=>$request->input('cin_no'),
            'bank_name'=>$request->input('bank_name'),
            'account_type'=>$request->input('account_type'),

            'adhar_no'=>$request->input('adhar_no'),
            'fssai'=>$request->input('fssai'),
            'lab_testing_report'=>$request->input('lab_testing_report'),
            'export_licence'=>$request->input('export_licence'),
            'data_source'=>$request->input('data_source'),
            'status'=>$request->input('status'),
            'conversation_details'=>$request->input('conversation_details'),
            'online_demo'=>$request->input('online_demo'),
            'executive_feedback'=>$request->input('executive_feedback'),
            'brand_name'=>$request->input('propsal_name'),
            'product_img'=>$request->input('product_img'),
            'fp_user_id'=>$request->input('fp_user_id'),

            'fp_psw'=>$request->input('fp_psw'),
            'bwt_catalog_link'=>$request->input('bwt_catalog_link'),
            'whats_up'=>$request->input('whats_up'),
            'executive_name'=>$request->input('executive_name'),
            'tl_manager_name'=>$request->input('tl_manager_name'),
          ]);
        return Redirect::back()->with('success', 'Company Register Data Update Successfully');
     }

     public function distinct()
     {
         $check = "SELECT DISTINCT company_name FROM `companies`";
         dd($check);
    }

}
